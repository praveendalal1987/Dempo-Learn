AI APPLICATIONS IN (NEW AGE) HR — TEACHING KIT
Srinivassa Sinai Dempo College (Autonomous), Goa · Dempo AI Business School
Authored by Praveen Dalal · Two-Year PGDM · Second Year · HRM Specialization Elective

Everything you need to teach this one course, in one place.

THE COURSE
  30 hours · 30 one-hour sessions · 6 modules. A hands-on studio course: students
  research, select, implement and build AI/SaaS HR tools, on dummy data throughout.
    Module 1 · Foundations: SaaS, AI & the HR Tech Landscape
    Module 2 · Gathering Needs & Defining Requirements
    Module 3 · Researching, Evaluating & Selecting Tools
    Module 4 · Implementing a Tool End-to-End
    Module 5 · Building AI-Based HR Tools
    Module 6 · Capstone: Demos & Synthesis

WHAT'S IN THIS KIT
  Course_Pack/        The full pack in Word + PDF — cover, about, contents, and the
                      session-by-session plan (facilitator notes, student handouts,
                      live tool examples, tools appendix, assessment scheme).
  Exam_Papers_with_Model_Answers/
                      Five specimen exam variants (2 hours / 60 marks) with model
                      answers and marking schemes, in Word + PDF. Rotate across terms.
                      Section A: any 4 of 5 (5 ea). Section B: any 2 of 3 (10 ea).
                      Section C: a compulsory case (20).
  Dummy_Dataset/      The AI/SaaS HR vendor-selection dataset (Excel) for the
                      evaluate/select exercises. (Internal cover sheet may still show
                      the prior course name; the data itself is course-ready.)
  AI_Applications_in_New_Age_HR_Preview_Cover_to_Contents_Dempo.pdf
                      A quick cover-to-contents preview to share or print.

TEACHING NOTES
  - All student work uses DUMMY data only — never real employee or salary data.
  - Tools named are live examples to verify yourself, not endorsements; the market
    moves fast, so check current features before class.
  - The course is studio-style: it runs on student work, demos and mentor guidance
    rather than lectures. The capstone is students building their own AI-based HR tool.
  - The Word files are editable if you want to localise examples or adjust pacing.
